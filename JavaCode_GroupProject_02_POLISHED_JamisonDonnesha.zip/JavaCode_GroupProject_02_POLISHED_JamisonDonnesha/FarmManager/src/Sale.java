import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** One line in the sales ledger (store sale, service payment, or animal sale). */
public class Sale {
    private final String type;
    private final String description;
    private final double amount;
    private final LocalDateTime when = LocalDateTime.now();

    public Sale(String type, String description, double amount) {
        this.type = type;
        this.description = description;
        this.amount = amount;
    }

    public String getType()        { return type; }
    public String getDescription() { return description; }
    public double getAmount()      { return amount; }

    @Override
    public String toString() {
        String t = when.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
        return String.format("%s | %-8s | %-35s | $%8.2f", t, type, description, amount);
    }
}
