import javax.swing.*;
import java.awt.*;

/** Main window. Run this class to start the program. */
public class FarmApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Business biz = new Business();

            JTabbedPane tabs = new JTabbedPane();
            tabs.addTab("Store", new StorePanel(biz));
            tabs.addTab("Services", new ServicesPanel(biz));
            tabs.addTab("Animals", new AnimalsPanel(biz));
            tabs.addTab("Reports", new ReportPanel(biz));

            // Refresh a tab whenever it is opened so data is never stale.
            tabs.addChangeListener(e -> {
                Component c = tabs.getSelectedComponent();
                if (c instanceof RefreshablePanel) {
                    ((RefreshablePanel) c).refresh();
                }
            });

            JFrame frame = new JFrame("Family Farm Manager");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.add(tabs);
            frame.setSize(950, 520);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}
