/** A scheduled service (exam, vaccination, etc.) and whether it has been paid. */
public class Appointment {
    private final String customer;
    private final String animalName;
    private final String service;
    private final String date;   // yyyy-MM-dd
    private final String time;   // HH:mm
    private final double price;
    private boolean paid;
    private String paymentMethod = "";

    public Appointment(String customer, String animalName, String service,
                       String date, String time, double price) {
        this.customer = customer;
        this.animalName = animalName;
        this.service = service;
        this.date = date;
        this.time = time;
        this.price = price;
    }

    public String getCustomer()      { return customer; }
    public String getAnimalName()    { return animalName; }
    public String getService()       { return service; }
    public String getDate()          { return date; }
    public String getTime()          { return time; }
    public double getPrice()         { return price; }
    public boolean isPaid()          { return paid; }
    public String getPaymentMethod() { return paymentMethod; }

    public void markPaid(String method) {
        paid = true;
        paymentMethod = method;
    }
}
