/** A product sold in the store. Animals extend this class (code reuse). */
public class Item {
    private String name;
    private String category;
    private double price;
    private int stock;

    public Item(String name, String category, double price, int stock) {
        this.name = name;
        this.category = category;
        this.price = price;
        this.stock = stock;
    }

    public String getName()     { return name; }
    public String getCategory() { return category; }
    public double getPrice()    { return price; }
    public int getStock()       { return stock; }

    /** Removes qty from stock. Returns false if the sale is not possible. */
    public boolean sell(int qty) {
        if (qty <= 0 || qty > stock) {
            return false;
        }
        stock -= qty;
        return true;
    }

    public void restock(int qty) {
        if (qty > 0) {
            stock += qty;
        }
    }
}
