import javax.swing.*;
import java.awt.*;

/** Tab that summarizes income and shows the full sales ledger. */
public class ReportPanel extends RefreshablePanel {
    private final Business biz;
    private final JTextArea area = new JTextArea();

    public ReportPanel(Business biz) {
        this.biz = biz;
        setLayout(new BorderLayout(8, 8));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        area.setEditable(false);
        area.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        add(new JScrollPane(area), BorderLayout.CENTER);
        JButton btn = new JButton("Refresh Report");
        btn.addActionListener(e -> refresh());
        add(btn, BorderLayout.SOUTH);
        refresh();
    }

    @Override
    public void refresh() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== FARM BUSINESS SUMMARY ===\n\n");
        sb.append(String.format("Store sales:      $%9.2f%n", biz.totalFor("Store")));
        sb.append(String.format("Service payments: $%9.2f%n", biz.totalFor("Service")));
        sb.append(String.format("Animal sales:     $%9.2f%n", biz.totalFor("Animal")));
        double total = biz.totalFor("Store") + biz.totalFor("Service") + biz.totalFor("Animal");
        sb.append(String.format("TOTAL INCOME:     $%9.2f%n%n", total));
        sb.append(String.format("Unpaid appointments: $%.2f%n%n", biz.outstandingBalance()));

        sb.append("Low-stock alerts (3 or fewer):\n");
        boolean any = false;
        for (Item i : biz.getItems()) {
            if (i.getStock() <= 3) { sb.append("  - ").append(i.getName()).append(" (").append(i.getStock()).append(")\n"); any = true; }
        }
        for (Animal a : biz.getAnimals()) {
            if (a.getStock() <= 3) { sb.append("  - ").append(a.getName()).append(" (").append(a.getStock()).append(")\n"); any = true; }
        }
        if (!any) sb.append("  None\n");

        sb.append("\n=== SALES LEDGER ===\n");
        if (biz.getSales().isEmpty()) {
            sb.append("No sales recorded yet.\n");
        }
        for (Sale s : biz.getSales()) {
            sb.append(s).append("\n");
        }
        area.setText(sb.toString());
        area.setCaretPosition(0);
    }
}
