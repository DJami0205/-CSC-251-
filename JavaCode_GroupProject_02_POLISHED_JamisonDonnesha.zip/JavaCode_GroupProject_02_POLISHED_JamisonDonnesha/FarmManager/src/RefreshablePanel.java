import javax.swing.JPanel;

/** Base class for every tab so the main window can refresh them the same way. */
public abstract class RefreshablePanel extends JPanel {
    public abstract void refresh();
}
