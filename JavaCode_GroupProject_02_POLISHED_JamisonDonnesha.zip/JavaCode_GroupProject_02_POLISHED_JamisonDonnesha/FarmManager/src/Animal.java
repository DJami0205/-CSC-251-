/** An animal for sale. Reuses Item (name = species, category = "Animal"). */
public class Animal extends Item {
    private String source;       // "Farm" or the name of a local breeder
    private boolean specialty;   // true for specialty resales from breeders

    public Animal(String species, double price, int stock, String source, boolean specialty) {
        super(species, "Animal", price, stock);
        this.source = source;
        this.specialty = specialty;
    }

    public String getSource()    { return source; }
    public boolean isSpecialty() { return specialty; }
}
