import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;

/** Tab for scheduling services and recording payments. */
public class ServicesPanel extends RefreshablePanel {
    private final Business biz;
    private final DefaultTableModel model;
    private final JTable table;
    private final JComboBox<String> serviceBox = new JComboBox<>(Business.SERVICE_NAMES);
    private final JTextField customerF = new JTextField(10);
    private final JTextField animalF = new JTextField(8);
    private final JTextField dateF = new JTextField(LocalDate.now().toString(), 8);
    private final JTextField timeF = new JTextField("09:00", 5);
    private final JComboBox<String> payBox = new JComboBox<>(new String[]{"Cash", "Card", "Check"});

    public ServicesPanel(Business biz) {
        this.biz = biz;
        setLayout(new BorderLayout(8, 8));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        model = new DefaultTableModel(
                new String[]{"Date", "Time", "Customer", "Animal", "Service", "Price", "Status"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel south = new JPanel(new GridLayout(2, 1, 5, 5));

        JPanel schedRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        schedRow.setBorder(BorderFactory.createTitledBorder("Schedule a service"));
        JButton schedBtn = new JButton("Schedule");
        schedRow.add(new JLabel("Service:"));  schedRow.add(serviceBox);
        schedRow.add(new JLabel("Customer:")); schedRow.add(customerF);
        schedRow.add(new JLabel("Animal:"));   schedRow.add(animalF);
        schedRow.add(new JLabel("Date (yyyy-MM-dd):")); schedRow.add(dateF);
        schedRow.add(new JLabel("Time (HH:mm):"));      schedRow.add(timeF);
        schedRow.add(schedBtn);

        JPanel payRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        payRow.setBorder(BorderFactory.createTitledBorder("Payment for selected appointment"));
        JButton payBtn = new JButton("Collect Payment");
        payRow.add(new JLabel("Method:"));
        payRow.add(payBox);
        payRow.add(payBtn);

        south.add(schedRow);
        south.add(payRow);
        add(south, BorderLayout.SOUTH);

        schedBtn.addActionListener(e -> schedule());
        payBtn.addActionListener(e -> collect());
        refresh();
    }

    private void schedule() {
        String customer = customerF.getText().trim();
        String animal = animalF.getText().trim();
        if (customer.isEmpty() || animal.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Customer and animal are required.");
            return;
        }
        try {
            LocalDate date = LocalDate.parse(dateF.getText().trim());
            LocalTime time = LocalTime.parse(timeF.getText().trim());
            if (date.isBefore(LocalDate.now())) {
                JOptionPane.showMessageDialog(this, "The date cannot be in the past.");
                return;
            }
            String service = (String) serviceBox.getSelectedItem();
            Appointment a = new Appointment(customer, animal, service,
                    date.toString(), time.toString(), Business.priceOfService(service));
            biz.schedule(a);
            customerF.setText("");
            animalF.setText("");
            refresh();
            JOptionPane.showMessageDialog(this, "Scheduled " + service + " for " + customer + ".");
        } catch (DateTimeParseException ex) {
            JOptionPane.showMessageDialog(this,
                    "Use date format yyyy-MM-dd (e.g. 2026-11-05) and time HH:mm (e.g. 14:30).");
        }
    }

    private void collect() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select an appointment first.");
            return;
        }
        Appointment a = biz.getAppointments().get(row);
        if (a.isPaid()) {
            JOptionPane.showMessageDialog(this, "That appointment is already paid.");
            return;
        }
        biz.collectPayment(a, (String) payBox.getSelectedItem());
        JOptionPane.showMessageDialog(this, String.format("Received $%.2f from %s (%s).",
                a.getPrice(), a.getCustomer(), a.getPaymentMethod()));
        refresh();
    }

    @Override
    public void refresh() {
        model.setRowCount(0);
        for (Appointment a : biz.getAppointments()) {
            model.addRow(new Object[]{a.getDate(), a.getTime(), a.getCustomer(), a.getAnimalName(),
                    a.getService(), String.format("$%.2f", a.getPrice()),
                    a.isPaid() ? "Paid (" + a.getPaymentMethod() + ")" : "Unpaid"});
        }
    }
}
