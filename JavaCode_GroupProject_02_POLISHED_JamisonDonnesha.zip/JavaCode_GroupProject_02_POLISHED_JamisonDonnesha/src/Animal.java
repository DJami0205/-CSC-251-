// Reuses Item: name is the species, category is always "Animal"
public class Animal extends Item {
    private final String source;      // "Farm" or a local breeder's name
    private final boolean specialty;  // true for specialty resales

    public Animal(String species, double price, int stock, String source, boolean specialty) {
        super(species, "Animal", price, stock);
        this.source = source;
        this.specialty = specialty;
    }

    public String getSource()    { return source; }
    public boolean isSpecialty() { return specialty; }
}
