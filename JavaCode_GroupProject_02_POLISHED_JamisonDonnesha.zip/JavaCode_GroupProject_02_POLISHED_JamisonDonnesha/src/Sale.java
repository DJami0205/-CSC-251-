import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Sale {
    private final String type, description;
    private final double amount;
    private final String time = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));

    public Sale(String type, String description, double amount) {
        this.type = type;
        this.description = description;
        this.amount = amount;
    }

    public String getType()        { return type; }
    public String getDescription() { return description; }
    public double getAmount()      { return amount; }
    public String getTimeText()    { return time; }

    @Override
    public String toString() {
        return String.format("%s | %-8s | %-35s | $%8.2f", time, type, description, amount);
    }
}
