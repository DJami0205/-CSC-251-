import java.io.*;
import java.util.*;
import java.util.zip.*;

// An .xlsx file is a zip of XML files, so no external library is needed
public class ExcelExporter {
    // Formula cell: Excel recalculates it; the cached value shows in viewers that don't
    private static class F {
        final String formula;
        final double value;
        F(String formula, double value) { this.formula = formula; this.value = value; }
    }

    public static void export(Business biz, File file) throws IOException {
        Map<String, List<Object[]>> sheets = new LinkedHashMap<>();

        List<Object[]> inv = new ArrayList<>();
        inv.add(new Object[]{"#", "Item", "Category", "Price", "In Stock", "Value"});
        double invValue = 0;
        int invUnits = 0, r = 2;
        for (Item i : biz.getItems()) {
            double v = i.getPrice() * i.getStock();
            inv.add(new Object[]{r - 1, i.getName(), i.getCategory(), i.getPrice(), i.getStock(),
                    new F("D" + r + "*E" + r, v)});
            invValue += v;
            invUnits += i.getStock();
            r++;
        }
        inv.add(new Object[]{"", "TOTAL", "", "", new F("SUM(E2:E" + (r - 1) + ")", invUnits),
                new F("SUM(F2:F" + (r - 1) + ")", invValue)});

        List<Object[]> ani = new ArrayList<>();
        ani.add(new Object[]{"#", "Species", "Price", "In Stock", "Source", "Type", "Value"});
        double aniValue = 0;
        int aniUnits = 0;
        r = 2;
        for (Animal a : biz.getAnimals()) {
            double v = a.getPrice() * a.getStock();
            ani.add(new Object[]{r - 1, a.getName(), a.getPrice(), a.getStock(), a.getSource(),
                    a.isSpecialty() ? "Specialty" : "Standard", new F("C" + r + "*D" + r, v)});
            aniValue += v;
            aniUnits += a.getStock();
            r++;
        }
        ani.add(new Object[]{"", "TOTAL", "", new F("SUM(D2:D" + (r - 1) + ")", aniUnits), "", "",
                new F("SUM(G2:G" + (r - 1) + ")", aniValue)});

        List<Object[]> app = new ArrayList<>();
        app.add(new Object[]{"#", "Date", "Time", "Customer", "Animal", "Service", "Price", "Status", "Payment Method"});
        double billed = 0;
        r = 2;
        for (Appointment a : biz.getAppointments()) {
            app.add(new Object[]{r - 1, a.getDate(), a.getTime(), a.getCustomer(), a.getAnimalName(),
                    a.getService(), a.getPrice(), a.isPaid() ? "Paid" : "Unpaid", a.getPaymentMethod()});
            billed += a.getPrice();
            r++;
        }
        String g = "G2:G" + (r - 1);
        app.add(new Object[]{"", "TOTAL BILLED", "", "", "", "", new F("SUM(" + g + ")", billed), "", ""});
        app.add(new Object[]{"", "UNPAID", "", "", "", "",
                new F("SUMIF(H2:H" + (r - 1) + ",\"Unpaid\"," + g + ")", biz.outstandingBalance()), "", ""});

        List<Object[]> led = new ArrayList<>();
        led.add(new Object[]{"#", "Date/Time", "Type", "Description", "Amount"});
        double income = 0;
        r = 2;
        for (Sale s : biz.getSales()) {
            led.add(new Object[]{r - 1, s.getTimeText(), s.getType(), s.getDescription(), s.getAmount()});
            income += s.getAmount();
            r++;
        }
        int last = r - 1;
        led.add(new Object[]{"", "TOTAL INCOME", "", "", new F("SUM(E2:E" + last + ")", income)});

        List<Object[]> sum = new ArrayList<>();
        sum.add(new Object[]{"Category", "Total"});
        for (String type : new String[]{"Store", "Service", "Animal"}) {
            String label = type.equals("Store") ? "Store sales"
                    : type.equals("Service") ? "Service payments" : "Animal sales";
            sum.add(new Object[]{label, new F("SUMIF('Sales Ledger'!C2:C" + last + ",\"" + type
                    + "\",'Sales Ledger'!E2:E" + last + ")", biz.totalFor(type))});
        }
        sum.add(new Object[]{"TOTAL INCOME", new F("SUM(B2:B4)", income)});
        sum.add(new Object[]{"Unpaid appointments", biz.outstandingBalance()});
        sum.add(new Object[]{"Inventory value (store)", invValue});
        sum.add(new Object[]{"Inventory value (animals)", aniValue});

        sheets.put("Summary", sum);
        sheets.put("Inventory", inv);
        sheets.put("Animals", ani);
        sheets.put("Appointments", app);
        sheets.put("Sales Ledger", led);
        write(file, sheets);
    }

    private static void write(File file, Map<String, List<Object[]>> sheets) throws IOException {
        final String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>";
        final String rel = "http://schemas.openxmlformats.org/officeDocument/2006/relationships";
        try (ZipOutputStream zip = new ZipOutputStream(new FileOutputStream(file))) {
            StringBuilder types = new StringBuilder(xml
                + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">"
                + "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>"
                + "<Default Extension=\"xml\" ContentType=\"application/xml\"/>"
                + "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>"
                + "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>");
            StringBuilder book = new StringBuilder(xml
                + "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"" + rel + "\"><sheets>");
            StringBuilder rels = new StringBuilder(xml
                + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">");
            int n = 1;
            for (Map.Entry<String, List<Object[]>> e : sheets.entrySet()) {
                types.append("<Override PartName=\"/xl/worksheets/sheet").append(n)
                     .append(".xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>");
                book.append("<sheet name=\"").append(esc(e.getKey())).append("\" sheetId=\"").append(n)
                    .append("\" r:id=\"rId").append(n).append("\"/>");
                rels.append("<Relationship Id=\"rId").append(n).append("\" Type=\"").append(rel)
                    .append("/worksheet\" Target=\"worksheets/sheet").append(n).append(".xml\"/>");
                put(zip, "xl/worksheets/sheet" + n + ".xml", sheetXml(e.getValue()));
                n++;
            }
            rels.append("<Relationship Id=\"rId").append(n).append("\" Type=\"").append(rel)
                .append("/styles\" Target=\"styles.xml\"/></Relationships>");
            put(zip, "[Content_Types].xml", types + "</Types>");
            put(zip, "_rels/.rels", xml
                + "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">"
                + "<Relationship Id=\"rId1\" Type=\"" + rel + "/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
            put(zip, "xl/workbook.xml", book + "</sheets></workbook>");
            put(zip, "xl/_rels/workbook.xml.rels", rels.toString());
            // Cell styles: 0 = normal, 1 = bold header, 2 = number with 2 decimals
            put(zip, "xl/styles.xml", xml
                + "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">"
                + "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font>"
                + "<font><b/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>"
                + "<fills count=\"2\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill></fills>"
                + "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>"
                + "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>"
                + "<cellXfs count=\"3\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>"
                + "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyFont=\"1\"/>"
                + "<xf numFmtId=\"2\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\" applyNumberFormat=\"1\"/></cellXfs>"
                + "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles>"
                + "</styleSheet>");
        }
    }

    // Row 0 is the bold header; columns are lettered A, B, C...
    private static String sheetXml(List<Object[]> rows) {
        StringBuilder sb = new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>"
            + "<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">"
            + "<cols><col min=\"1\" max=\"" + rows.get(0).length + "\" width=\"20\" customWidth=\"1\"/></cols><sheetData>");
        for (int r = 0; r < rows.size(); r++) {
            sb.append("<row r=\"").append(r + 1).append("\">");
            Object[] row = rows.get(r);
            for (int c = 0; c < row.length; c++) {
                String ref = (char) ('A' + c) + "" + (r + 1);
                Object v = row[c];
                if (r == 0) {
                    text(sb, ref, v, " s=\"1\"");
                } else if (v instanceof F) {
                    sb.append("<c r=\"").append(ref).append("\" s=\"2\"><f>").append(esc(((F) v).formula))
                      .append("</f><v>").append(((F) v).value).append("</v></c>");
                } else if (v instanceof Double) {
                    sb.append("<c r=\"").append(ref).append("\" s=\"2\"><v>").append(v).append("</v></c>");
                } else if (v instanceof Integer) {
                    sb.append("<c r=\"").append(ref).append("\"><v>").append(v).append("</v></c>");
                } else {
                    text(sb, ref, v, "");
                }
            }
            sb.append("</row>");
        }
        return sb.append("</sheetData></worksheet>").toString();
    }

    private static void text(StringBuilder sb, String ref, Object v, String style) {
        sb.append("<c r=\"").append(ref).append("\"").append(style).append(" t=\"inlineStr\"><is><t>")
          .append(esc(String.valueOf(v))).append("</t></is></c>");
    }

    private static void put(ZipOutputStream zip, String name, String content) throws IOException {
        zip.putNextEntry(new ZipEntry(name));
        zip.write(content.getBytes("UTF-8"));
        zip.closeEntry();
    }

    private static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }
}
