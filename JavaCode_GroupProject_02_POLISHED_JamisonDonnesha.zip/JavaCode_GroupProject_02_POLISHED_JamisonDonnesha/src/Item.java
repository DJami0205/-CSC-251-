public class Item {
    private final String name;
    private final String category;
    private final double price;
    private int stock;

    public Item(String name, String category, double price, int stock) {
        this.name = name;
        this.category = category;
        this.price = price;
        this.stock = stock;
    }

    public String getName()     { return name; }
    public String getCategory() { return category; }
    public double getPrice()    { return price; }
    public int getStock()       { return stock; }

    // Returns false (and changes nothing) if qty is invalid or exceeds stock
    public boolean sell(int qty) {
        if (qty <= 0 || qty > stock) {
            return false;
        }
        stock -= qty;
        return true;
    }

    public void restock(int qty) {
        if (qty > 0) {
            stock += qty;
        }
    }
}
