public class Appointment {
    private final String customer, animalName, service, date, time;
    private final double price;
    private boolean paid;
    private String paymentMethod = "";

    public Appointment(String customer, String animalName, String service,
                       String date, String time, double price) {
        this.customer = customer;
        this.animalName = animalName;
        this.service = service;
        this.date = date;
        this.time = time;
        this.price = price;
    }

    public String getCustomer()      { return customer; }
    public String getAnimalName()    { return animalName; }
    public String getService()       { return service; }
    public String getDate()          { return date; }
    public String getTime()          { return time; }
    public double getPrice()         { return price; }
    public boolean isPaid()          { return paid; }
    public String getPaymentMethod() { return paymentMethod; }

    public void markPaid(String method) {
        paid = true;
        paymentMethod = method;
    }
}
