import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Business {
    public static final String[] SERVICE_NAMES = {"Wellness Exam", "Vaccination", "Hoof/Nail Trim",
                                                  "Basic Treatment", "Health Certificate"};
    public static final double[] SERVICE_PRICES = {45.00, 25.00, 15.00, 60.00, 35.00};

    private final List<Item> items = new ArrayList<>();
    private final List<Animal> animals = new ArrayList<>();
    private final List<Appointment> appointments = new ArrayList<>();
    private final List<Sale> sales = new ArrayList<>();

    public Business() {
        loadSampleData();
        loadSampleActivity();
    }

    private void loadSampleData() {
        items.add(new Item("Chicken Feed 50lb", "Feed", 24.99, 30));
        items.add(new Item("Horse Feed 50lb", "Feed", 29.99, 20));
        items.add(new Item("Hay Bale", "Feed", 8.50, 60));
        items.add(new Item("Pet Bedding", "Supplies", 12.75, 25));
        items.add(new Item("Water Trough", "Equipment", 39.00, 8));
        items.add(new Item("Poultry Fencing Roll", "Equipment", 54.50, 6));
        items.add(new Item("Dewormer", "Health", 14.25, 15));
        animals.add(new Animal("Duck", 12.00, 10, "Farm", false));
        animals.add(new Animal("Chicken", 9.50, 20, "Farm", false));
        animals.add(new Animal("Hamster", 15.00, 6, "Farm", false));
        animals.add(new Animal("Rabbit", 25.00, 8, "Farm", false));
        animals.add(new Animal("Silkie Chicken", 35.00, 4, "Smith Breeders", true));
    }

    // Demo transactions; remove the call in the constructor to start with an empty ledger
    private void loadSampleActivity() {
        sellItem(items.get(0), 3);
        sellItem(items.get(2), 10);
        sellItem(items.get(4), 1);
        sellItem(items.get(6), 2);
        sellAnimal(animals.get(0), 2, "Maria Lopez");
        sellAnimal(animals.get(3), 1, "Tom Baker");
        sellAnimal(animals.get(4), 1, "Jenny Cole");
        LocalDate today = LocalDate.now();
        Appointment a1 = new Appointment("Maria Lopez", "Biscuit (dog)", "Vaccination",
                today.toString(), "09:00", priceOfService("Vaccination"));
        Appointment a2 = new Appointment("Dan Reyes", "Daisy (goat)", "Hoof/Nail Trim",
                today.toString(), "10:30", priceOfService("Hoof/Nail Trim"));
        Appointment a3 = new Appointment("Sue Park", "Clover (horse)", "Wellness Exam",
                today.plusDays(2).toString(), "14:00", priceOfService("Wellness Exam"));
        schedule(a1);
        schedule(a2);
        schedule(a3);
        collectPayment(a1, "Card");
        collectPayment(a2, "Cash");
    }

    public List<Item> getItems()               { return items; }
    public List<Animal> getAnimals()           { return animals; }
    public List<Appointment> getAppointments() { return appointments; }
    public List<Sale> getSales()               { return sales; }

    // Returns the sale total, or -1 if there is not enough stock
    public double sellItem(Item item, int qty) {
        if (!item.sell(qty)) {
            return -1;
        }
        double total = item.getPrice() * qty;
        sales.add(new Sale("Store", qty + " x " + item.getName(), total));
        return total;
    }

    // Returns the sale total, or -1 if there is not enough stock
    public double sellAnimal(Animal a, int qty, String buyer) {
        if (!a.sell(qty)) {
            return -1;
        }
        double total = a.getPrice() * qty;
        sales.add(new Sale("Animal", qty + " x " + a.getName() + " to " + buyer, total));
        return total;
    }

    public void schedule(Appointment appt) {
        appointments.add(appt);
    }

    // Ignored if already paid, so income is never recorded twice
    public void collectPayment(Appointment appt, String method) {
        if (!appt.isPaid()) {
            appt.markPaid(method);
            sales.add(new Sale("Service", appt.getService() + " - " + appt.getCustomer(), appt.getPrice()));
        }
    }

    public double totalFor(String type) {
        double sum = 0;
        for (Sale s : sales) {
            if (s.getType().equals(type)) {
                sum += s.getAmount();
            }
        }
        return sum;
    }

    public double outstandingBalance() {
        double sum = 0;
        for (Appointment a : appointments) {
            if (!a.isPaid()) {
                sum += a.getPrice();
            }
        }
        return sum;
    }

    public static double priceOfService(String name) {
        for (int i = 0; i < SERVICE_NAMES.length; i++) {
            if (SERVICE_NAMES[i].equals(name)) {
                return SERVICE_PRICES[i];
            }
        }
        return 0;
    }
}
