import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class AnimalsPanel extends RefreshablePanel {
    private final Business biz;
    private final DefaultTableModel model;
    private final JTable table;
    private final JSpinner qty = new JSpinner(new SpinnerNumberModel(1, 1, 500, 1));
    private final JTextField buyerF = new JTextField(10), speciesF = new JTextField(10);
    private final JTextField priceF = new JTextField(6), stockF = new JTextField(4);
    private final JTextField breederF = new JTextField(10);
    private final JCheckBox specialtyBox = new JCheckBox("Specialty resale from breeder");

    public AnimalsPanel(Business biz) {
        this.biz = biz;
        setLayout(new BorderLayout(8, 8));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        model = new DefaultTableModel(new String[]{"Species", "Price", "In Stock", "Source", "Type"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel sellRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        sellRow.setBorder(BorderFactory.createTitledBorder("Sell selected animal"));
        JButton sellBtn = new JButton("Sell");
        sellRow.add(new JLabel("Buyer:"));    sellRow.add(buyerF);
        sellRow.add(new JLabel("Quantity:")); sellRow.add(qty);
        sellRow.add(sellBtn);

        JPanel addRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        addRow.setBorder(BorderFactory.createTitledBorder("Add animals to inventory"));
        JButton addBtn = new JButton("Add Animals");
        addRow.add(new JLabel("Species:")); addRow.add(speciesF);
        addRow.add(new JLabel("Price:"));   addRow.add(priceF);
        addRow.add(new JLabel("Count:"));   addRow.add(stockF);
        addRow.add(new JLabel("Breeder (blank = farm):")); addRow.add(breederF);
        addRow.add(specialtyBox);
        addRow.add(addBtn);

        JPanel south = new JPanel(new GridLayout(2, 1, 5, 5));
        south.add(sellRow);
        south.add(addRow);
        add(south, BorderLayout.SOUTH);

        sellBtn.addActionListener(e -> sell());
        addBtn.addActionListener(e -> addAnimals());
        refresh();
    }

    private void sell() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select an animal first.");
            return;
        }
        String buyer = buyerF.getText().trim();
        if (buyer.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter the buyer's name.");
            return;
        }
        Animal a = biz.getAnimals().get(row);
        int q = (Integer) qty.getValue();
        double total = biz.sellAnimal(a, q, buyer);
        if (total < 0) {
            JOptionPane.showMessageDialog(this, "Not enough animals in stock.",
                    "Sale failed", JOptionPane.WARNING_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this,
                    String.format("Sold %d x %s to %s%nTotal: $%.2f", q, a.getName(), buyer, total));
            buyerF.setText("");
        }
        refresh();
    }

    private void addAnimals() {
        String species = speciesF.getText().trim(), breeder = breederF.getText().trim();
        if (species.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Species is required.");
            return;
        }
        if (specialtyBox.isSelected() && breeder.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Specialty resales need a breeder name.");
            return;
        }
        try {
            double price = Double.parseDouble(priceF.getText().trim());
            int count = Integer.parseInt(stockF.getText().trim());
            if (price < 0 || count <= 0) {
                JOptionPane.showMessageDialog(this, "Price must be 0 or more and count at least 1.");
                return;
            }
            biz.getAnimals().add(new Animal(species, price, count,
                    breeder.isEmpty() ? "Farm" : breeder, specialtyBox.isSelected()));
            speciesF.setText(""); priceF.setText(""); stockF.setText(""); breederF.setText("");
            specialtyBox.setSelected(false);
            refresh();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Price must be a number and count a whole number.");
        }
    }

    @Override
    public void refresh() {
        model.setRowCount(0);
        for (Animal a : biz.getAnimals()) {
            model.addRow(new Object[]{a.getName(), String.format("$%.2f", a.getPrice()),
                    a.getStock(), a.getSource(), a.isSpecialty() ? "Specialty" : "Standard"});
        }
    }
}
