import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ReportPanel extends RefreshablePanel {
    private final Business biz;
    private final JTextArea area = new JTextArea();

    public ReportPanel(Business biz) {
        this.biz = biz;
        setLayout(new BorderLayout(8, 8));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        area.setEditable(false);
        area.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        add(new JScrollPane(area), BorderLayout.CENTER);

        JButton refreshBtn = new JButton("Refresh Report");
        JButton excelBtn = new JButton("Export to Excel (.xlsx)");
        refreshBtn.addActionListener(e -> refresh());
        excelBtn.addActionListener(e -> exportExcel());
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttons.add(refreshBtn);
        buttons.add(excelBtn);
        add(buttons, BorderLayout.SOUTH);
        refresh();
    }

    private void exportExcel() {
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File("FarmData.xlsx"));
        if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        File file = chooser.getSelectedFile();
        if (!file.getName().toLowerCase().endsWith(".xlsx")) {
            file = new File(file.getPath() + ".xlsx");
        }
        try {
            ExcelExporter.export(biz, file);
            JOptionPane.showMessageDialog(this, "Saved Excel file:\n" + file.getAbsolutePath());
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Could not save file: " + ex.getMessage(),
                    "Export failed", JOptionPane.ERROR_MESSAGE);
        }
    }

    @Override
    public void refresh() {
        double total = biz.totalFor("Store") + biz.totalFor("Service") + biz.totalFor("Animal");
        StringBuilder sb = new StringBuilder("=== FARM BUSINESS SUMMARY ===\n\n");
        sb.append(String.format("Store sales:      $%9.2f%n", biz.totalFor("Store")));
        sb.append(String.format("Service payments: $%9.2f%n", biz.totalFor("Service")));
        sb.append(String.format("Animal sales:     $%9.2f%n", biz.totalFor("Animal")));
        sb.append(String.format("TOTAL INCOME:     $%9.2f%n%n", total));
        sb.append(String.format("Unpaid appointments: $%.2f%n%n", biz.outstandingBalance()));

        // Animal is an Item, so one list covers both inventories
        List<Item> all = new ArrayList<>(biz.getItems());
        all.addAll(biz.getAnimals());
        sb.append("Low-stock alerts (3 or fewer):\n");
        boolean any = false;
        for (Item i : all) {
            if (i.getStock() <= 3) {
                sb.append("  - ").append(i.getName()).append(" (").append(i.getStock()).append(")\n");
                any = true;
            }
        }
        if (!any) sb.append("  None\n");

        sb.append("\n=== SALES LEDGER ===\n");
        if (biz.getSales().isEmpty()) sb.append("No sales recorded yet.\n");
        for (Sale s : biz.getSales()) sb.append(s).append("\n");
        area.setText(sb.toString());
        area.setCaretPosition(0);
    }
}
