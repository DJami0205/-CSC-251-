import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class StorePanel extends RefreshablePanel {
    private final Business biz;
    private final DefaultTableModel model;
    private final JTable table;
    private final JSpinner qty = new JSpinner(new SpinnerNumberModel(1, 1, 1000, 1));
    private final JTextField nameF = new JTextField(10), catF = new JTextField(8);
    private final JTextField priceF = new JTextField(6), stockF = new JTextField(4);

    public StorePanel(Business biz) {
        this.biz = biz;
        setLayout(new BorderLayout(8, 8));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        model = new DefaultTableModel(new String[]{"Item", "Category", "Price", "In Stock"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel sellRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        sellRow.setBorder(BorderFactory.createTitledBorder("Sell / Restock selected item"));
        JButton sellBtn = new JButton("Sell"), restockBtn = new JButton("Restock");
        sellRow.add(new JLabel("Quantity:"));
        sellRow.add(qty);
        sellRow.add(sellBtn);
        sellRow.add(restockBtn);

        JPanel addRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        addRow.setBorder(BorderFactory.createTitledBorder("Add new product"));
        JButton addBtn = new JButton("Add Product");
        addRow.add(new JLabel("Name:"));     addRow.add(nameF);
        addRow.add(new JLabel("Category:")); addRow.add(catF);
        addRow.add(new JLabel("Price:"));    addRow.add(priceF);
        addRow.add(new JLabel("Stock:"));    addRow.add(stockF);
        addRow.add(addBtn);

        JPanel south = new JPanel(new GridLayout(2, 1, 5, 5));
        south.add(sellRow);
        south.add(addRow);
        add(south, BorderLayout.SOUTH);

        sellBtn.addActionListener(e -> sell());
        restockBtn.addActionListener(e -> restock());
        addBtn.addActionListener(e -> addProduct());
        refresh();
    }

    // Table rows match list order, so the selected row is the list index
    private Item selected() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select an item in the table first.");
            return null;
        }
        return biz.getItems().get(row);
    }

    private void sell() {
        Item item = selected();
        if (item == null) return;
        int q = (Integer) qty.getValue();
        double total = biz.sellItem(item, q);
        if (total < 0) {
            JOptionPane.showMessageDialog(this, "Not enough stock for that sale.",
                    "Sale failed", JOptionPane.WARNING_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this,
                    String.format("Sold %d x %s%nTotal: $%.2f", q, item.getName(), total));
        }
        refresh();
    }

    private void restock() {
        Item item = selected();
        if (item == null) return;
        item.restock((Integer) qty.getValue());
        refresh();
    }

    private void addProduct() {
        String name = nameF.getText().trim(), cat = catF.getText().trim();
        if (name.isEmpty() || cat.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Name and category are required.");
            return;
        }
        try {
            double price = Double.parseDouble(priceF.getText().trim());
            int stock = Integer.parseInt(stockF.getText().trim());
            if (price < 0 || stock < 0) {
                JOptionPane.showMessageDialog(this, "Price and stock cannot be negative.");
                return;
            }
            biz.getItems().add(new Item(name, cat, price, stock));
            nameF.setText(""); catF.setText(""); priceF.setText(""); stockF.setText("");
            refresh();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Price must be a number (e.g. 9.99) and stock a whole number.");
        }
    }

    @Override
    public void refresh() {
        model.setRowCount(0);
        for (Item i : biz.getItems()) {
            model.addRow(new Object[]{i.getName(), i.getCategory(),
                    String.format("$%.2f", i.getPrice()), i.getStock()});
        }
    }
}
